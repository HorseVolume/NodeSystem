Triangle Pattern
http://dryicons.com/free-graphics/preview/triangle-pattern/


Licensing
----------------------

The usage of DryIcons' work (icons, icon sets and graphics) is limited to the terms of the "Free License", "Commercial License" and "Extended License" use.

The DryIcons Free License means that you can use our icons, icon sets and graphics in any publicly accessible web site, web application or any form of presentation publicly accessible through the World Wide Web only according to the DryIcons Free License Terms and Conditions:

* You must put a back link with credits to http://dryicons.com on every page where DryIcons' Works are used (example: Icons by http://dryicons.com);

* You must include the correct back link to DryIcons website, which is: http://dryicons.com;

* You must place the link on an easy-to-see, recognizable place, so there is no confusion about the Original Author of the Works (DryIcons);

* When copying, or paraphrasing description text (or title) on one of the Works, you must make sure there are no spelling mistakes;

* Do not try to take credit or imply in any way that you and not DryIcons is the Original Author of the Works (icons, icon sets and graphics).

For a more detailed look at our Free License Agreement, please follow the link: http://dryicons.com/terms/#free-license


The DryIcons Commercial License means that you can use our Icon Sets and Graphics without being obligated to put a back link to DryIcons.com for a certain fee. After you complete your payment transaction DryIcons grants you a Commercial License.

For a more detailed look at our Commercial License Agreement, please follow the link: http://dryicons.com/terms/#commercial-license

DryIcons Extended License for physical and electronic sale and distribution means that you can use our Icon Sets and Graphics within your software and desktop applications that you intend to sell, web templates, wallpapers, promotional materials,  on T-shirts, postcards, mouse pads, coffee mugs, calendars or similar, for a certain fee. After you complete your payment transaction DryIcons grants you an Extended License.

For a more detailed look at our Extended License Agreement, please follow the link: http://dryicons.com/terms/#extended-license
